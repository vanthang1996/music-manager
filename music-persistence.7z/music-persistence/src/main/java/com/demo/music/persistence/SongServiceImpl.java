package com.demo.music.persistence;

import java.util.List;

import javax.inject.Singleton;

import org.apache.aries.blueprint.annotation.service.Service;
import org.apache.aries.blueprint.annotation.service.ServiceProperty;
import org.hibernate.Query;
import org.hibernate.Session;

import com.demo.music.model.ServiceDAOGenneric;
import com.demo.music.model.Song;

@Singleton
@Service(classes = ServiceDAOGenneric.class, properties = { @ServiceProperty(name = "music.song.service", values = "*") })
public class SongServiceImpl implements ServiceDAOGenneric<Song> {
	/*@Inject
	@Reference
	SessionFactory sessionFactory;*/

	@Override
	public void add(Song item) {
		Session session = HibernateConfig.factory().openSession();
		session.save(item);
		session.close();
	}

	@Override
	public void update(String tId, Song item) {
//		for (Song song : songs) {
//			if (song.getSongId() == item.getSongId()) {
//				song.update(item);
//				return;
//			}
//		}
	}

	@Override
	public void delete(String tId) {
		// for (Song song : songs) {
//			if (song.getSongId().equals(tId)) {
//				songs.remove(song);
//				return;
//			}
		// }//

	}

	@Override
	public List<Song> getAll() {
		
		Session session = HibernateConfig.factory().openSession();
		Query<Song> query = session.createQuery("from  Song ");
		List<Song> artists = query.getResultList();
		session.close();
		return artists;
	}

	@Override
	public Song findById(String iTd) {
		Session session = HibernateConfig.factory().openSession();
		Query<Song> query = session.createQuery("from Song s where s.songId=:songId");
		query.setString("songId", iTd);
		Song artist = query.getSingleResult();
		session.close();
		return artist;
	}

}
