package com.demo.music.persistence;

import java.util.List;

import javax.inject.Singleton;

import org.apache.aries.blueprint.annotation.service.Service;
import org.apache.aries.blueprint.annotation.service.ServiceProperty;
import org.hibernate.Query;
import org.hibernate.Session;

import com.demo.music.model.Artist;
import com.demo.music.model.ServiceDAOGenneric;

@Service(classes = ServiceDAOGenneric.class, properties = {
		@ServiceProperty(name = "music.artis.service", values = "*"), })
@Singleton
public class ArtistServiceImpl implements ServiceDAOGenneric<Artist> {
	/*
	 * @Inject
	 * 
	 * @Reference HibernateConfig.sessionFactory HibernateConfig.sessionFactory;
	 */

	@Override
	public void add(Artist item) {
		Session session = HibernateConfig.factory().openSession();
		session.save(item);
		session.close();

	}

	@Override
	public void update(String tId, Artist item) {
//		for (Artist artist : artists) {
//			if (artist.getArtistId() == item.getArtistId()) {
//				artist.update(item);
//				return;
//			}
//		}

	}

	@Override
	public void delete(String tId) {
//		for (Artist artist : artists) {
//			if (artist.getArtistId().equals(tId)) {
//				artists.remove(artist);
//				return;
//			}
//		}

	}

	@Override
	public List<Artist> getAll() {
		Session session = HibernateConfig.factory().openSession();
		Query<Artist> query = session.createQuery("from  Artist ");
		List<Artist> artists = query.getResultList();
		session.close();
		return artists;
	}

	@Override
	public Artist findById(String tId) {
		Session session = HibernateConfig.factory().openSession();
		Query<Artist> query = session.createQuery("from Artist a where a.artistId=:artistId");
		query.setString("artistId", tId);
		Artist artist = query.getSingleResult();
		session.close();
		return artist;
	}

}
