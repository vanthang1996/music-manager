package com.demo.music.persistence;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.util.List;

import javax.inject.Singleton;

import org.apache.aries.blueprint.annotation.service.Service;
import org.apache.aries.blueprint.annotation.service.ServiceProperty;

import com.demo.music.model.ServiceDAOGenneric;
/*
@Service(classes = ServiceDAOGenneric.class, properties = {
		@ServiceProperty(name = "music.artis.service", values = "*"),
		@ServiceProperty(name = "objectClass", values = "ServiceDAOGenneric") })
@Singleton
public class DAOImpl<T extends Serializable> implements ServiceDAOGenneric<T> {

	public DAOImpl() {

	}

	void getType() {
		ParameterizedType genericSuperclass = (ParameterizedType) this.getClass().getGenericSuperclass();
		System.out.println(genericSuperclass.getActualTypeArguments());
	}

	@Override
	public void add(T item) {
		// TODO Auto-generated method stub

	}

	@Override
	public void update(String tId, T item) {
		// TODO Auto-generated method stub

	}

	@Override
	public void delete(String tId) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<T> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public T findById(String iTd) {
		// TODO Auto-generated method stub
		return null;
	}

	public static void main(String[] args) {
		DAOImpl<HibernateConfig> daoImpl = new DAOImpl<HibernateConfig>();
		daoImpl.getType();

	}

}
*/