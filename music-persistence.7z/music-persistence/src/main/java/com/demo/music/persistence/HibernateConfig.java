package com.demo.music.persistence;

import java.io.Serializable;
import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.dialect.MySQL5Dialect;
import org.hibernate.dialect.MySQLDialect;

import com.demo.music.model.Artist;
import com.demo.music.model.Song;
import com.mysql.cj.jdbc.Driver;

public class HibernateConfig implements Serializable {

	/*
	 * @Service(classes = SessionFactory.class, properties = {
	 * 
	 * @ServiceProperty(name = "session.factory.hibernate", values = "*") })
	 * 
	 * @Singleton
	 */
	public static SessionFactory factory() {
		SessionFactory factory = getConfigHibernate().buildSessionFactory();
		return factory;
	}

	/* @Service */
	public static Configuration getConfigHibernate() {
		Properties properties = new Properties();

		properties.setProperty("hibernate.connection.driver_class", Driver.class.getName());
		properties.setProperty("hibernate.connection.url", "jdbc:mysql://localhost:3306/music-manage");
		properties.setProperty("hibernate.connection.username", "root");
		properties.setProperty("hibernate.connection.password", "");
		properties.setProperty("hibernate.dialect", MySQLDialect.class.getName());
		properties.setProperty("hibernate.show_sql", "true");
		properties.setProperty("hibernate.connection.pool_si;ze", "10");
		Configuration configuration = new Configuration().addProperties(properties).addAnnotatedClass(Song.class)
				.addAnnotatedClass(Artist.class);
//				.addPackage("com.demo.hibernate.model");

		return configuration;
	}

	public static void main(String[] args) {
		System.out.println(MySQL5Dialect.class.getName());
	}

	/*
	 * public static void main(String[] args) { Session session =
	 * factory().openSession(); String hql = "select s from Song s"; Query query =
	 * session.createQuery(hql); List<Song> list = query.getResultList(); for (Song
	 * song : list) { System.out.println(song); } session.close(); }
	 */
}
